package id.sman10.fokusbelajar

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Menahan (menghapus) notifikasi selama sesi fokus aktif. */
class NotifBlocker : NotificationListenerService() {
    // Aplikasi yang tetap boleh masuk (telepon). Tambahkan paket lain di sini bila perlu.
    private val allow = setOf(
        "com.android.dialer", "com.google.android.dialer",
        "com.samsung.android.dialer", "com.android.server.telecom"
    )

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val p = getSharedPreferences("fokus", MODE_PRIVATE)
        if (p.getLong("end", 0) <= System.currentTimeMillis()) return
        if (sbn.packageName == packageName || sbn.packageName in allow || sbn.isOngoing) return
        cancelNotification(sbn.key)
        p.edit().putInt("blocked", p.getInt("blocked", 0) + 1).apply()
    }
}
