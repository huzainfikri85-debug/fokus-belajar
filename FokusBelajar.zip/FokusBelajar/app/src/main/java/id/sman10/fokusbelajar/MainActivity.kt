package id.sman10.fokusbelajar

import android.app.ActivityManager
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.os.CountDownTimer
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var tvTimer: TextView
    private lateinit var tvInfo: TextView
    private lateinit var tvLog: TextView
    private lateinit var etMenit: EditText
    private lateinit var btnStart: Button
    private var timer: CountDownTimer? = null

    private fun active() = prefs.getLong("end", 0) > System.currentTimeMillis()
    private fun listenerOn() =
        Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("fokus", MODE_PRIVATE)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad * 2, pad, pad)
        }
        tvTimer = TextView(this).apply { textSize = 56f; text = "00:00"; gravity = Gravity.CENTER }
        tvInfo = TextView(this).apply { textSize = 16f; gravity = Gravity.CENTER }
        etMenit = EditText(this).apply {
            hint = "Durasi (menit)"; inputType = InputType.TYPE_CLASS_NUMBER; setText("45")
        }
        btnStart = Button(this).apply { text = "Mulai Fokus"; setOnClickListener { startFocus() } }
        val btnAkses = Button(this).apply {
            text = "Beri Akses Notifikasi"
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        }
        tvLog = TextView(this).apply { textSize = 13f; setPadding(0, pad, 0, 0) }
        listOf(tvTimer, tvInfo, etMenit, btnStart, btnAkses, tvLog).forEach { root.addView(it) }
        setContentView(ScrollView(this).apply { addView(root) })

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (active()) Toast.makeText(this@MainActivity, "Selesaikan timer dulu!", Toast.LENGTH_SHORT).show()
                else { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
            }
        })
    }

    override fun onResume() {
        super.onResume()
        if (active()) { lockIfNeeded(); runTimer() } else idleUi()
    }

    private fun startFocus() {
        if (!listenerOn()) {
            Toast.makeText(this, "Aktifkan akses notifikasi untuk aplikasi ini dulu", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)); return
        }
        val menit = etMenit.text.toString().toIntOrNull()?.coerceIn(1, 240) ?: return
        prefs.edit().putLong("end", System.currentTimeMillis() + menit * 60_000L)
            .putLong("start", System.currentTimeMillis()).putInt("blocked", 0).apply()
        lockIfNeeded(); runTimer()
    }

    private fun lockIfNeeded() {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        if (am.lockTaskModeState == ActivityManager.LOCK_TASK_MODE_NONE) startLockTask()
    }

    private fun runTimer() {
        timer?.cancel()
        btnStart.isEnabled = false; etMenit.isEnabled = false
        timer = object : CountDownTimer(prefs.getLong("end", 0) - System.currentTimeMillis(), 1000) {
            override fun onTick(ms: Long) {
                val s = ms / 1000
                tvTimer.text = String.format("%02d:%02d", s / 60, s % 60)
                tvInfo.text = "Fokus aktif • ${prefs.getInt("blocked", 0)} notifikasi ditahan"
            }
            override fun onFinish() = finishFocus()
        }.start()
    }

    private fun finishFocus() {
        val blocked = prefs.getInt("blocked", 0)
        val menit = ((prefs.getLong("end", 0) - prefs.getLong("start", 0)) / 60_000).toInt()
        val tgl = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("id")).format(Date())
        val log = prefs.getString("log", "") + "$tgl | $menit menit | $blocked notifikasi ditahan\n"
        prefs.edit().putLong("end", 0).putString("log", log).apply()
        try { stopLockTask() } catch (_: Exception) {}
        idleUi()
        tvInfo.text = "Sesi selesai! $blocked notifikasi ditahan."
    }

    private fun idleUi() {
        timer?.cancel(); tvTimer.text = "00:00"
        btnStart.isEnabled = true; etMenit.isEnabled = true
        if (tvInfo.text.isNullOrEmpty()) tvInfo.text = "Siap belajar?"
        val log = prefs.getString("log", "") ?: ""
        tvLog.text = if (log.isEmpty()) "" else "Riwayat sesi:\n$log"
    }
}
